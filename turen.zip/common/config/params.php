<?php
return [
    'user.passwordResetTokenExpire' => 3600,//找回密码的有效时间
];
