<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\User */
?>



<?php 
echo '预约电话：';
echo '<br />';
echo '称呼-'.$from['name'];
echo '<br />';
echo '电话-'.$from['contact'];
?>

