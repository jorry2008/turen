
<?= $this->context->action->uniqueId ?>
<br />
<?= $this->context->action->id ?>

