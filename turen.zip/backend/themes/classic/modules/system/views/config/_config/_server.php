<b>
	Server
</b>
<p>
	Exactly like the original bootstrap tabs except you should use the custom
	wrapper
	<code>
		.nav-tabs-custom
	</code>
	to achieve this style.
</p>