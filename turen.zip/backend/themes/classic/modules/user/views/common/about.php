<?php
use yii\helpers\Html;

/* @var $this yii\web\View */

$this->title = Yii::t('user', 'About Us');
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="row">
	<div class="col-md-12">
	
	<div class="site-about">
	    <h1><?= Html::encode($this->title) ?></h1>
	
	    <p>This is the About page. You may modify the following file to customize its content:</p>
	
	    <code><?= __FILE__ ?></code>
	    <br><br><br><br><br><br><br>
	    
	    1.简介
	    <br />
	    
	    2.团队介绍
	    <br />
	    
	    3.各种联系方式
	    <br />
	    
	    4.展望
	    <br />
	    
	    5.公司时间轴
	    <br />
	    
	    
	    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	</div>
	
	</div>
</div>

