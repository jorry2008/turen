<?php

namespace backend\modules\auth;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\auth\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
