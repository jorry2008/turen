<?php

namespace backend\modules\catalog;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\catalog\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
