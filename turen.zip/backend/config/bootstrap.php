<?php
//upload后台资源
Yii::setAlias('upload', dirname(__DIR__) . '/web/upload');
